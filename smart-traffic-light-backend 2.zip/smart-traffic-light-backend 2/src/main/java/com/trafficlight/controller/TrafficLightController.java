package com.trafficlight.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/signal")
@CrossOrigin(origins = "http://localhost:3000")
public class TrafficLightController {
    @GetMapping
    public String getSignal(@RequestParam Map<String, String> densities) {
        String highestDensityRoad = densities.entrySet()
            .stream()
            .max(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey)
            .orElse("north");

        return "{ \"signal\": \"" + highestDensityRoad + "\" }";
    }
}