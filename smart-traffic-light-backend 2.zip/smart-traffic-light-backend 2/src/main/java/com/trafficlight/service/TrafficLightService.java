package com.trafficlight.service;

import com.trafficlight.model.TrafficLight;
import org.springframework.stereotype.Service;

@Service
public class TrafficLightService {

    public TrafficLight getTrafficLightState(int vehicleDensity) {
        if (vehicleDensity > 50) { // High density
            return new TrafficLight("GREEN", 60);
        } else if (vehicleDensity > 20) { // Medium density
            return new TrafficLight("YELLOW", 10);
        } else { // Low density
            return new TrafficLight("RED", 30);
        }
    }
}
